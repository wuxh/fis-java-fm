package fis.test;

import java.util.Map;

import fis.front.FISException;
import fis.front.FISResource;
import fis.front.FisDataUtil;

public class FISLoadTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, Object> data2 = FisDataUtil.getJSON("./data/test_data.json");
		System.out.println(data2);
		try {
			FISResource fisRes = new FISResource();
			String uri = fisRes.load("lib/css/bootstrap-responsive.css");
			String uri2 = fisRes.load("app1:lib/css/bootstrap-responsive.css");
			System.out.println("uri : " + uri);
			System.out.println("uri2 : " + uri2);
		} catch (FISException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
