1. fis-site为fis官网演示项目的前端开发代码目录，Web为前后端代码发布运行目录，src为后端java源码目录。
2. fis-site站点运行脚本命令(示例,参数可自行调整)为：
#先命令行下切换到fis-site目录，运行命令
fis release --dest ../Web -m -p