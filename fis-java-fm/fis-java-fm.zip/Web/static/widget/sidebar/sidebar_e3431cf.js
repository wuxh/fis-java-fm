define('widget/sidebar/sidebar.js', function(require, exports, module){

$('.btn-navbar').click(function() {
    $('html').toggleClass('expanded');
});

});