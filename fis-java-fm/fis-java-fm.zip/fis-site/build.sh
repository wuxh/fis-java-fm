#!/bin/bash

fis -v --no-color
# fis release -Dumopd local --no-color
fis release --domains --md5 --optimize --pack --unique --dest ../Web --no-color