$('.btn-navbar').click(function() {
    $('html').toggleClass('expanded');
});